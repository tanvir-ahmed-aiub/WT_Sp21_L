
		<!--addproduct ends -->
		<!--footer-->
		<footer class="footer">
			<h4>Webtech Dummy Project</h4>
		</footer>
		
	</body>
</html>