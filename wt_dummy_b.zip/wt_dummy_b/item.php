<?php include 'main_header.php';?>
<!--item starts -->
<div class="center">
	<table>
		<tr>
			<td>
				<img class="item-image" src="https://m.media-amazon.com/images/I/41n0GIKkW8L._AC_SR160,160_.jpg"></img>
				<input type="number" placeholder="1" style="width:185px;font-family:consolas;margin-top:5px;" class="form-control">
				<div class="add-to-cart"><a class="btn btn-success" style="width:185px;font-family:consolas;margin-top:5px;">Add to Cart</a></span></div>
			</td>
			<td>
				<h1 class="text">Note 7 Pro</h1>
				<h2 class="text">BDT 15500</h2>
				<p class="text"> Lorem ipsum dolor ut sit ame dolore adipiscing elit, sed nonumy nibh sed euismod laoreet dolore magna aliquarm erat volutpat Nostrud duis molestie at dolore.</p>
				
			</td>
		</tr>
	</table>
	
</div>

<!--item ends -->
<?php include 'main_footer.php';?>